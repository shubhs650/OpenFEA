import time
with open('growth', 'wb') as f:
 for _ in range(32):
  f.write(bytes(1024**2)); f.flush(); time.sleep(.02)
