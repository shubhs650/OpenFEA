import time
a=[]
for _ in range(64):
 a.append(bytearray(16*1024**2))
 time.sleep(.02)
